#
# INTRODUCTION TO R - TUTORIAL
# By: Nadia Muhe
# Data: Canadian Community Health Survey (CCHS), 2022 (Annual Component)
# Documentation: https://odesi.ca/en/details?id=/odesi/doi__10-5683_SP3_FFQB3B.xml 
# Download link: https://borealisdata.ca/data-explorer/?siteUrl=https:%2F%2Fborealisdata.ca&dvLocale=en&fileId=1002657 
#===============================================================================


#---------------------------#
# RStudio                   #
#---------------------------#

# Search and Help
??csv
help(read.table)



#---------------------------#
# IMPORTING DATA            #
#---------------------------#

# Working Directory
getwd()
setwd("/path/to/your/folder")   # paste the path to the saved dataset
dir()


# Import CSV File
cchs_csv <- read.csv("cchs.csv")


# Import RDS File (R Data Object)
cchs <- readRDS("cchs.rds")



#---------------------------#
# EXPLORING DATA            #
#---------------------------#

# Data Overview
dim(cchs)
str(cchs)
head(cchs)
tail(cchs)
names(cchs)

# Displaying Rows & Columns: Square Brackets
cchs[1, 3]
cchs[1, "age_group"]
cchs[1, 1:3]
cchs[60000:60005, c("health", "mental_health", "activity")]


# Variable: Incorrect vs Correct Approach
mental_health
cchs$mental_health


# Frequency Table
table(cchs$mental_health)
table(cchs$mental_health, useNA = "ifany")


# Two-Way Frequency Table
# install.packages("gmodels")
library(gmodels)
CrossTable(cchs$mental_health)
CrossTable(cchs$mental_health, cchs$income_quintile)


# Missing Data
is.na(cchs$mental_health)
sum(is.na(cchs$mental_health))
sum(!is.na(cchs$mental_health))


# Summary Statistics
summary(cchs$life_sat)
mean(cchs$life_sat, na.rm = TRUE)
sd(cchs$life_sat, na.rm = TRUE)
summary(cchs$life_sat[cchs$province == "ON"])

# Grouped Summary Statistics
# life_sat grouped by province
by(cchs$life_sat, cchs$province, summary)
# life_sat grouped by food_security
by(cchs$life_sat, cchs$food_security, summary)
# Alternative approach to by()
aggregate(life_sat ~ food_security, data = cchs, summary)



#--------------#
# GRAPHS       #
#--------------#

# Bar Chart
stress_table <- table(cchs$stress)
barplot(stress_table)
barplot(stress_table, 
        main = "Stress Levels in the 2022 CCHS",  
        ylab = "Frequency",
        xlab = "Stress Level")


# Histogram
hist(cchs$life_sat)
hist(cchs$life_sat, breaks = seq(-0.5, 10.5, by = 1))
hist(cchs$life_sat, 
     breaks = seq(-0.5, 10.5, by = 1),
     main = "Life Satisfaction",  
     xlab = "Life Satisfaction Score", 
     col = "lightblue")


# Scatterplot
plot(cchs$sleep_hours, cchs$life_sat)
plot(jitter(cchs$sleep_hours), jitter(cchs$life_sat))
plot(jitter(cchs$sleep_hours), jitter(cchs$life_sat), pch = 3, cex = 0.7, col = "darkred")
plot(jitter(cchs$sleep_hours), jitter(cchs$life_sat), pch = 3, cex = 0.7, col = cchs$sex)
plot(jitter(cchs$sleep_hours), jitter(cchs$life_sat), 
     pch = 3, cex = 0.7, col = cchs$sex,
     main = "Sleep Hours and Life Satisfaction by Sex",
     ylab = "Life Satisfaction Score", 
     xlab = "Sleep Hours")
# Add legend
legend("bottomright", legend = levels(cchs$sex), col = 1:2, pch = 3)



#---------------------------#
# NEW VARIABLES             #
#---------------------------# 

# Example 1: Binary Variable
# Food Insecurity Indicator
table(cchs$food_security, useNA = "ifany")
cchs$food_insecure <- ifelse(cchs$food_security == "Secure", 0, 1)
# Check
table(cchs$food_security, cchs$food_insecure, useNA = "ifany")


# Example 2: Categorical Variable
# Smoking & Drinking Risk Categories
table(cchs$smoking, useNA = "ifany")
table(cchs$drinking, useNA = "ifany")

cchs$risk <- NA
cchs$risk[cchs$smoking == "Current" & cchs$drinking == "Regular"] <- "Both"
cchs$risk[cchs$smoking == "Current" & cchs$drinking != "Regular"] <- "Smoker"
cchs$risk[cchs$smoking != "Current" & cchs$drinking == "Regular"] <- "Drinker"
cchs$risk[cchs$smoking != "Current" & cchs$drinking != "Regular"] <- "Neither"
# Check
table(cchs$smoking, cchs$drinking, useNA = "ifany")
table(cchs$risk, useNA = "ifany")

# Convert from character to factor
str(cchs$risk)
cchs$risk <- factor(cchs$risk, levels = c("Both", "Smoker", "Drinker", "Neither"))
str(cchs$risk)
table(cchs$risk, useNA = "ifany")


# Example 3: Count Variable
# Total Chronic Conditions Reported
cchs$chronic_count <- rowSums(cbind(cchs$diabetes, cchs$hbp, cchs$cholesterol, cchs$mood, 
                                cchs$anxiety, cchs$fatigue, cchs$msk, cchs$cardiovascular), 
                      na.rm = TRUE)
# Check
table(cchs$chronic_count, useNA = "ifany")



#-------------------#
# SAVING DATA       #
#-------------------#

# Saving R Object
saveRDS(cchs, file = "cchs_analysis.rds")

# Exporting Data as CSV
write.csv(cchs, file = "cchs_analysis.csv", row.names = FALSE)



#-------------------#
# MANAGING DATA     #
#-------------------#

# Subsetting by Variables (Columns)
lifestyle <- subset(cchs, select = c(id, sleep_hours, activity, fruit_veg, screen_workday, screen_offday))

# Subsetting by Observations (Rows)
young_adult_screen_complete <- subset(cchs, age_group == "18-34" & !is.na(screen_workday) & !is.na(screen_offday))

# Sorting Data
cchs <- cchs[order(cchs$income), ]
cchs <- cchs[order(cchs$income, decreasing = TRUE), ] # highest to lowest






